include Ast

let rec string_of_expression_value e =
  match e with
  | Application (e, arg) ->
    (string_of_expression_value e) ^ " (" ^ string_of_expression_value arg ^ ")"
  | Identifier name -> name

module Substitution : sig
  type 'a t

  val empty : 'a t
  val singleton : string -> 'a -> 'a t
  val merge : 'a t -> 'a t -> 'a t option
  val find : string -> 'a t -> 'a option
  val print_subst : expression t option -> unit
end = struct
  type 'a t = (string * 'a) list

  let empty = []

  let singleton key value = [(key, value)]

  let rec find key sub =
    match sub with
    | [] -> None
    | (k, v) :: rest -> if k = key then Some v else find key rest

  let rec merge sub1 sub2 =
    match sub1 with
    | [] -> Some sub2
    | (k, v) :: rest ->
        match find k sub2 with
        | None -> merge rest ((k, v) :: sub2)
        | Some v2 -> if v = v2 then merge rest sub2 else None


  let print_subst (s : expression t option) : unit =
    match s with
    | Some subst ->
        List.iter (fun (k, v) -> print_endline (k ^ " -> " ^ string_of_expression_value v)) subst
    | None -> print_endline "Substitution is None"
end

