include Ast
include Substitution
module Parser = Parser
module Lexer = Lexer

(* let parse_2 (s : string) : declaration list =
  let lexbuf = Lexing.from_string s in
  let ast = Parser.main Lexer.token lexbuf in
     ast *)

let parse (s : string) : expression =
      let lexbuf = Lexing.from_string s in
      let ast = Parser.expression_eof
      Lexer.token lexbuf in ast

let rec string_of_expression (e : expression) : string =
  match e with
  | Application (e, arg) ->
    (string_of_expression e) ^ " (" ^ string_of_expression arg ^ ")"
  | Identifier name -> name

let string_of_hint (h : hint option) : string =
  match h with
  | Some Axiom -> "\n(*hint: axiom *)"
  | None -> ""
let string_of_equality (e : equality) : string =
  match e with
  | Equality (e1, e2) -> "(" ^ (string_of_expression e1) ^ " = " ^ (string_of_expression e2) ^ ")"
let string_of_typedvariable (TypedVariable (name, type_name) : typedVariable) : string =
  "(" ^ name ^ " : " ^ type_name ^ ")"
let string_of_declaration (d : declaration) : string =
  match d with
  | ProofDeclaration (name, args, equality, hint) ->
    let arg_strings = List.map string_of_typedvariable args in
    "let (*prove*) " ^ name ^ " " ^ (String.concat " " arg_strings) ^ " = "
     ^ string_of_equality equality ^ string_of_hint hint



   let rec match_expression vars pattern goal =
    match pattern with
    | Identifier name when List.mem name vars -> 
      Some (Substitution.singleton name goal)
    | Identifier _ -> 
      if pattern = goal then Some Substitution.empty else None
    | Application (f1, a1) -> 
      (match goal with
      | Application (f2, a2) -> 
        (match match_expression vars f1 f2, match_expression vars a1 a2 with
        | Some subst1, Some subst2 -> Substitution.merge subst1 subst2
        | _, _ -> None)
      | _ -> None)

    let rec substitute variables subst expr =
      match expr with
      | Identifier name when List.mem name variables ->
        begin match Substitution.find name subst with
        | Some value -> value
        | None -> expr
        end
      | Application (f, arg) -> Application (substitute variables subst f, substitute variables subst arg)
      | _ -> expr

      let rec attempt_rewrite variables eq expr =
        let lhs, rhs = eq in
        match match_expression variables lhs expr with
        | Some subst -> Some (substitute variables subst rhs)
        | None -> 
          match expr with
          | Application (f, arg) -> 
            (match attempt_rewrite variables eq f, attempt_rewrite variables eq arg with
            | Some f', _ -> Some (Application (f', arg))
            | _, Some arg' -> Some (Application (f, arg'))
            | _, _ -> None)
          | _ -> None
      
      let rec tryEqualities equalities expr =
        match equalities with
        | [] -> None
        | (name, variables, lhs, rhs) :: rest ->
          match attempt_rewrite variables (lhs, rhs) expr with
          | Some expr' -> Some (name, expr')
          | None -> tryEqualities rest expr

      let rec performSteps equalities expr =
        match tryEqualities equalities expr with
        | None -> []
        | Some (name, expr') -> (name, expr') :: performSteps equalities expr'

        let rec produceProof lhs_steps rhs_steps lhs rhs =
          match lhs_steps, rhs_steps with
          | (name, expr) :: _, _ when expr = rhs -> [name]
          | _, (name, expr) :: _ when expr = lhs -> [name]
          | (name, expr) :: lhs_rest, _ -> name :: produceProof lhs_rest rhs_steps expr rhs
          | _, (name, expr) :: rhs_rest -> name :: produceProof lhs_steps rhs_rest lhs expr
          | [], [] -> []
        
        let prover_simple equalities (lhs, rhs) =
          let lhs_steps = performSteps equalities lhs in
          let rhs_steps = performSteps equalities rhs in
          produceProof lhs_steps rhs_steps lhs rhs

          let rec proofs_of_simple eqs lst =
            match lst with
            | [] -> []
            | (ProofDeclaration (nm,_,Equality(lhs, rhs),hint_option))::decls
              -> let proof_steps = prover_simple eqs (lhs, rhs) in
                 let proof_strings = List.map (fun (name, expr) -> 
                     match name with
                     | "???" -> " = ??? Could not determine a next proof step ???\n  " ^ (string_of_expression expr)
                     | _ -> " = {" ^ name ^ "}\n  " ^ (string_of_expression expr)
                   ) proof_steps in
                 let hint = match hint_option with
                            | Some Axiom -> ["Axiom"]
                            | None -> [] in
                 (("Proof of "^nm^":\n  " ^ (string_of_expression lhs)) :: proof_strings)
                 :: (proofs_of_simple (((nm,lhs),hint,lhs,rhs)::eqs) decls)
            (* | _::decls -> proofs_of_simple eqs decls *)
          
          let produce_output_simple (lst : declaration list) =
            print_endline (String.concat "\n\n"
              (List.map (String.concat "\n")
                (proofs_of_simple [] lst)))